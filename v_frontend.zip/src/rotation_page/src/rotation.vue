<template>
  <Rotation_Main></Rotation_Main>
</template>

<script>
import Rotation_Main from "@/rotation_page/src/components/Rotation_Main.vue";

export default {
    name:"rotationApp",
    components: {Rotation_Main},
}
</script>

<style scoped>
</style>